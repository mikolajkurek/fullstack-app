package org.example.pasir_kurek_mikolaj.service;

import jakarta.persistence.EntityNotFoundException;
import org.example.pasir_kurek_mikolaj.dto.DebtDTO;
import org.example.pasir_kurek_mikolaj.model.Debt;
import org.example.pasir_kurek_mikolaj.model.Group;
import org.example.pasir_kurek_mikolaj.model.User;
import org.example.pasir_kurek_mikolaj.repository.DebtRepository;
import org.example.pasir_kurek_mikolaj.repository.GroupRepository;
import org.example.pasir_kurek_mikolaj.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DebtService {
    private final DebtRepository debtRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    public DebtService(DebtRepository debtRepository, GroupRepository groupRepository, UserRepository userRepository) {
        this.debtRepository = debtRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    public List<Debt> getGroupDebts(Long groupId) {
        return debtRepository.findByGroupId(groupId);
    }

    public Debt createDebt(DebtDTO debtDTO) {
        Group group = groupRepository.findById(debtDTO.getGroupId())
                .orElseThrow(() -> new EntityNotFoundException("Nie znaleziono grupy o ID: " + debtDTO.getGroupId()));
        User debtor = userRepository.findById(debtDTO.getDebtorId())
                .orElseThrow(() -> new EntityNotFoundException("Nie znaleziono dluznika o ID: " + debtDTO.getDebtorId()));
        User creditor = userRepository.findById(debtDTO.getCreditorId())
                .orElseThrow(() -> new EntityNotFoundException("Nie znaleziono wierzyciela o ID: " + debtDTO.getCreditorId()));
        Debt debt = new Debt();
        debt.setGroup(group);
        debt.setDebtor(debtor);
        debt.setCreditor(creditor);
        debt.setAmount(debtDTO.getAmount());
        debt.setTitle(debtDTO.getTitle());
        return debtRepository.save(debt);
    }

    public Boolean deleteDebt(Long debtId) {
        if (!debtRepository.existsById(debtId)) {
            throw new EntityNotFoundException("Zadłużenie o ID " + debtId + " nie istnieje.");
        }
        try {
            debtRepository.deleteById(debtId);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("Nie udało się usunąć zadłużenia: " + e.getMessage());
        }
    }
}