package org.example.pasir_kurek_mikolaj.controller;

import org.example.pasir_kurek_mikolaj.dto.BalanceDTO;
import org.example.pasir_kurek_mikolaj.dto.TransactionDTO;
import org.example.pasir_kurek_mikolaj.model.Transaction;
import org.example.pasir_kurek_mikolaj.model.User;
import org.example.pasir_kurek_mikolaj.service.TransactionService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@Validated
public class TransactionGraphQLController {

    private final TransactionService transactionService;

    public TransactionGraphQLController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @QueryMapping(name="transactions")
    public List<Transaction> transactions() {
        return transactionService.getAllTransactions();
    }

    @MutationMapping
    public Transaction addTransaction(@Valid @Argument TransactionDTO transactionDTO) {
        return transactionService.createTransaction(transactionDTO);
    }

    @MutationMapping
    public Transaction updateTransaction(
            @Argument Long id,
            @Valid @Argument TransactionDTO transactionDTO
    ) {
        return transactionService.updateTransaction(id, transactionDTO);
    }

    @MutationMapping
    public Boolean deleteTransaction(@Argument Long id) {
        return transactionService.deleteTransaction(id);
    }

    @QueryMapping
    public BalanceDTO userBalance(@Argument Float days) {
        User user = transactionService.getCurrentUser();
        return transactionService.getUserBalance(user, days);
    }

    @QueryMapping
    public List<Transaction> filteredTransactions(
            @Argument String type,
            @Argument String tags,
            @Argument Double minAmount,
            @Argument Double maxAmount,
            @Argument String startDate,
            @Argument String endDate) {

        LocalDateTime startDateTime = null;
        LocalDateTime endDateTime = null;

        if (startDate != null && !startDate.isEmpty()) {
            try {
                startDateTime = LocalDateTime.parse(startDate);
            } catch (Exception e) {
                // Ignoruj nieprawidłowy format
            }
        }

        if (endDate != null && !endDate.isEmpty()) {
            try {
                endDateTime = LocalDateTime.parse(endDate);
            } catch (Exception e) {
                // Ignoruj nieprawidłowy format
            }
        }

        return transactionService.getFilteredTransactions(
                type, tags, minAmount, maxAmount, startDateTime, endDateTime);
    }
}