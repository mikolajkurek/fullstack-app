package org.example.pasir_kurek_mikolaj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaSiRKurekMikolajApplicationTests {

    @Test
    void contextLoads() {
    }

}
