package org.example.pasir_kurek_mikolaj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaSiRKurekMikolajApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaSiRKurekMikolajApplication.class, args);
    }

}
