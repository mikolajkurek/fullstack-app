package org.example.pasir_kurek_mikolaj.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}
